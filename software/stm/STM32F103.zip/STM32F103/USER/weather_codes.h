#ifndef __WEATHER_CODES_H
#define __WEATHER_CODES_H

const char* get_weather_description(int code);
#endif
